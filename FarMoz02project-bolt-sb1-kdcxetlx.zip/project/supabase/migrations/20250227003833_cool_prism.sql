/*
  # Pharmacy and Medication Database Schema

  1. New Tables
    - `pharmacies`
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `address` (text, not null)
      - `city` (text, not null)
      - `province` (text, not null)
      - `phone` (text)
      - `email` (text)
      - `website` (text)
      - `opening_hours` (jsonb)
      - `coordinates` (point)
      - `is_24h` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `owner_id` (uuid, foreign key to auth.users)
    
    - `medications`
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `generic_name` (text)
      - `description` (text)
      - `dosage_form` (text) - e.g., tablet, capsule, liquid
      - `strength` (text) - e.g., 500mg, 10mg/ml
      - `manufacturer` (text)
      - `requires_prescription` (boolean)
      - `category` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `pharmacy_medications`
      - `id` (uuid, primary key)
      - `pharmacy_id` (uuid, foreign key to pharmacies)
      - `medication_id` (uuid, foreign key to medications)
      - `price` (numeric)
      - `in_stock` (boolean)
      - `stock_quantity` (integer)
      - `last_updated` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own pharmacies
    - Add policies for public read access to pharmacies and medications
    - Add policies for pharmacy owners to manage their medication inventory
*/

-- Create extension for generating UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create pharmacies table
CREATE TABLE IF NOT EXISTS pharmacies (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  province text NOT NULL,
  phone text,
  email text,
  website text,
  opening_hours jsonb DEFAULT '{"monday": {"open": "08:00", "close": "18:00"}, "tuesday": {"open": "08:00", "close": "18:00"}, "wednesday": {"open": "08:00", "close": "18:00"}, "thursday": {"open": "08:00", "close": "18:00"}, "friday": {"open": "08:00", "close": "18:00"}, "saturday": {"open": "08:00", "close": "13:00"}, "sunday": {"open": null, "close": null}}',
  coordinates point,
  is_24h boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Create medications table
CREATE TABLE IF NOT EXISTS medications (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  generic_name text,
  description text,
  dosage_form text,
  strength text,
  manufacturer text,
  requires_prescription boolean DEFAULT false,
  category text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create pharmacy_medications junction table
CREATE TABLE IF NOT EXISTS pharmacy_medications (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  pharmacy_id uuid REFERENCES pharmacies(id) ON DELETE CASCADE,
  medication_id uuid REFERENCES medications(id) ON DELETE CASCADE,
  price numeric,
  in_stock boolean DEFAULT true,
  stock_quantity integer,
  last_updated timestamptz DEFAULT now(),
  UNIQUE(pharmacy_id, medication_id)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_pharmacy_medications_pharmacy_id ON pharmacy_medications(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_medications_medication_id ON pharmacy_medications(medication_id);
CREATE INDEX IF NOT EXISTS idx_pharmacies_owner_id ON pharmacies(owner_id);
CREATE INDEX IF NOT EXISTS idx_pharmacies_province_city ON pharmacies(province, city);
CREATE INDEX IF NOT EXISTS idx_medications_name ON medications(name);
CREATE INDEX IF NOT EXISTS idx_medications_category ON medications(category);

-- Enable Row Level Security
ALTER TABLE pharmacies ENABLE ROW LEVEL SECURITY;
ALTER TABLE medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE pharmacy_medications ENABLE ROW LEVEL SECURITY;

-- Policies for pharmacies
-- Anyone can view pharmacies
CREATE POLICY "Pharmacies are viewable by everyone" 
  ON pharmacies 
  FOR SELECT 
  USING (true);

-- Only authenticated owners can insert their own pharmacies
CREATE POLICY "Users can insert their own pharmacies" 
  ON pharmacies 
  FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() = owner_id);

-- Only pharmacy owners can update their pharmacies
CREATE POLICY "Users can update their own pharmacies" 
  ON pharmacies 
  FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = owner_id);

-- Only pharmacy owners can delete their pharmacies
CREATE POLICY "Users can delete their own pharmacies" 
  ON pharmacies 
  FOR DELETE 
  TO authenticated 
  USING (auth.uid() = owner_id);

-- Policies for medications
-- Anyone can view medications
CREATE POLICY "Medications are viewable by everyone" 
  ON medications 
  FOR SELECT 
  USING (true);

-- Only authenticated users with special permissions can manage medications
-- For now, we'll allow all authenticated users to add medications (can be restricted later)
CREATE POLICY "Authenticated users can insert medications" 
  ON medications 
  FOR INSERT 
  TO authenticated 
  WITH CHECK (true);

-- Policies for pharmacy_medications
-- Anyone can view pharmacy_medications
CREATE POLICY "Pharmacy medications are viewable by everyone" 
  ON pharmacy_medications 
  FOR SELECT 
  USING (true);

-- Only pharmacy owners can manage their medication inventory
CREATE POLICY "Pharmacy owners can insert medications to their inventory" 
  ON pharmacy_medications 
  FOR INSERT 
  TO authenticated 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM pharmacies 
      WHERE id = pharmacy_medications.pharmacy_id 
      AND owner_id = auth.uid()
    )
  );

CREATE POLICY "Pharmacy owners can update their medication inventory" 
  ON pharmacy_medications 
  FOR UPDATE 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM pharmacies 
      WHERE id = pharmacy_medications.pharmacy_id 
      AND owner_id = auth.uid()
    )
  );

CREATE POLICY "Pharmacy owners can delete medications from their inventory" 
  ON pharmacy_medications 
  FOR DELETE 
  TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM pharmacies 
      WHERE id = pharmacy_medications.pharmacy_id 
      AND owner_id = auth.uid()
    )
  );

-- Create function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers to automatically update the updated_at column
CREATE TRIGGER update_pharmacies_updated_at
BEFORE UPDATE ON pharmacies
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_medications_updated_at
BEFORE UPDATE ON medications
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Create trigger to automatically update the last_updated column in pharmacy_medications
CREATE TRIGGER update_pharmacy_medications_last_updated
BEFORE UPDATE ON pharmacy_medications
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();