export type Pharmacy = {
  id: string;
  name: string;
  address: string;
  city: string;
  province: string;
  phone?: string;
  email?: string;
  website?: string;
  opening_hours?: {
    monday?: { open: string; close: string };
    tuesday?: { open: string; close: string };
    wednesday?: { open: string; close: string };
    thursday?: { open: string; close: string };
    friday?: { open: string; close: string };
    saturday?: { open: string; close: string };
    sunday?: { open: string; close: string };
  };
  coordinates?: { x: number; y: number };
  is_24h: boolean;
  created_at: string;
  updated_at: string;
  owner_id: string;
};

export type Medication = {
  id: string;
  name: string;
  generic_name?: string;
  description?: string;
  dosage_form?: string;
  strength?: string;
  manufacturer?: string;
  requires_prescription: boolean;
  category?: string;
  created_at: string;
  updated_at: string;
};

export type PharmacyMedication = {
  id: string;
  pharmacy_id: string;
  medication_id: string;
  price?: number;
  in_stock: boolean;
  stock_quantity?: number;
  last_updated: string;
};

export type PharmacyWithMedications = Pharmacy & {
  medications: (Medication & { 
    pharmacy_medication: PharmacyMedication 
  })[];
};

export type MedicationWithPharmacies = Medication & {
  pharmacies: (Pharmacy & { 
    pharmacy_medication: PharmacyMedication 
  })[];
};