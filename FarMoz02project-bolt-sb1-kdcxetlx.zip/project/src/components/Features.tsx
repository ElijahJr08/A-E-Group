import React from 'react';
import { MapPin, Pill as Pills, Phone, Clock, Truck, UserPlus } from 'lucide-react';

const features = [
  {
    name: 'Localização',
    description: 'Encontre farmácias próximas a você em todo Moçambique',
    icon: MapPin,
  },
  {
    name: 'Medicamentos',
    description: 'Pesquise medicamentos e verifique disponibilidade',
    icon: Pills,
  },
  {
    name: 'Consultas Online',
    description: 'Fale com médicos em tempo real',
    icon: Phone,
  },
  {
    name: '24/7 Disponível',
    description: 'Encontre farmácias abertas a qualquer hora',
    icon: Clock,
  },
  {
    name: 'Entrega',
    description: 'Receba seus medicamentos em casa',
    icon: Truck,
  },
  {
    name: 'Cadastro Fácil',
    description: 'Crie sua conta em poucos minutos',
    icon: UserPlus,
  },
];

const Features = () => {
  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-emerald-600 font-semibold tracking-wide uppercase">Funcionalidades</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Tudo que você precisa em um só lugar
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Acesse todos os serviços de saúde de forma simples e rápida
          </p>
        </div>

        <div className="mt-10">
          <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div key={feature.name} className="pt-6">
                <div className="flow-root bg-gray-50 rounded-lg px-6 pb-8">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-emerald-500 rounded-md shadow-lg">
                        <feature.icon className="h-6 w-6 text-white" aria-hidden="true" />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight">{feature.name}</h3>
                    <p className="mt-5 text-base text-gray-500">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;