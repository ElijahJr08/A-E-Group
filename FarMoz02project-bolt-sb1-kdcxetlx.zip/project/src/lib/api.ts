import { supabase, isSupabaseConfigured } from './supabase';
import type { Pharmacy, Medication, PharmacyMedication } from '../types/database.types';

// Pharmacy API functions
export const getPharmacies = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .select('*')
    .order('name');
};

export const getPharmacyById = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .select(`
      *,
      pharmacy_medications(
        *,
        medications(*)
      )
    `)
    .eq('id', id)
    .single();
};

export const createPharmacy = async (pharmacy: Omit<Pharmacy, 'id' | 'created_at' | 'updated_at'>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .insert(pharmacy)
    .select()
    .single();
};

export const updatePharmacy = async (id: string, pharmacy: Partial<Pharmacy>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .update(pharmacy)
    .eq('id', id)
    .select()
    .single();
};

export const deletePharmacy = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .delete()
    .eq('id', id);
};

// Medication API functions
export const getMedications = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .select('*')
    .order('name');
};

export const getMedicationById = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .select(`
      *,
      pharmacy_medications(
        *,
        pharmacies(*)
      )
    `)
    .eq('id', id)
    .single();
};

export const createMedication = async (medication: Omit<Medication, 'id' | 'created_at' | 'updated_at'>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .insert(medication)
    .select()
    .single();
};

export const updateMedication = async (id: string, medication: Partial<Medication>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .update(medication)
    .eq('id', id)
    .select()
    .single();
};

export const deleteMedication = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .delete()
    .eq('id', id);
};

// Pharmacy Medication API functions
export const addMedicationToPharmacy = async (pharmacyMedication: Omit<PharmacyMedication, 'id' | 'last_updated'>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .insert(pharmacyMedication)
    .select()
    .single();
};

export const updatePharmacyMedication = async (id: string, pharmacyMedication: Partial<PharmacyMedication>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .update(pharmacyMedication)
    .eq('id', id)
    .select()
    .single();
};

export const removePharmacyMedication = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .delete()
    .eq('id', id);
};

// Search functions
export const searchPharmacies = async (query: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .select('*')
    .or(`name.ilike.%${query}%, address.ilike.%${query}%, city.ilike.%${query}%`)
    .order('name');
};

export const searchMedications = async (query: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .select('*')
    .or(`name.ilike.%${query}%, generic_name.ilike.%${query}%, description.ilike.%${query}%`)
    .order('name');
};

export const findPharmaciesWithMedication = async (medicationId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .select(`
      *,
      pharmacies(*),
      medications(*)
    `)
    .eq('medication_id', medicationId)
    .eq('in_stock', true)
    .order('price');
};