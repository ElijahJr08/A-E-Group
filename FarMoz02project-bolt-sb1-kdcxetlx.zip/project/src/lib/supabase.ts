import { createClient } from '@supabase/supabase-js';

// Get environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if credentials are missing
const isMissingCredentials = !supabaseUrl || !supabaseKey;

// Create a mock client or real client based on available credentials
let supabaseClient: any;

if (isMissingCredentials) {
  console.warn(
    'Supabase credentials are missing. Please connect to Supabase by clicking the "Connect to Supabase" button in the top right corner.'
  );
  
  // Create a mock client with dummy methods
  supabaseClient = {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      signUp: async () => ({ data: null, error: new Error('Supabase not configured') }),
      signInWithPassword: async () => ({ data: null, error: new Error('Supabase not configured') }),
      signOut: async () => ({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
    },
    // Add other methods as needed
  };
} else {
  // Create the real Supabase client
  supabaseClient = createClient(supabaseUrl, supabaseKey);
}

export const supabase = supabaseClient;

// Helper function to check if Supabase is properly configured
export const isSupabaseConfigured = () => !isMissingCredentials;