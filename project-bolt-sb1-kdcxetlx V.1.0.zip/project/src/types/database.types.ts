export type Pharmacy = {
  id: string;
  name: string;
  address: string;
  city: string;
  province: string;
  phone?: string;
  email?: string;
  website?: string;
  opening_hours?: {
    monday?: { open: string; close: string };
    tuesday?: { open: string; close: string };
    wednesday?: { open: string; close: string };
    thursday?: { open: string; close: string };
    friday?: { open: string; close: string };
    saturday?: { open: string; close: string };
    sunday?: { open: string; close: string };
  };
  coordinates?: { x: number; y: number };
  is_24h: boolean;
  created_at: string;
  updated_at: string;
  owner_id: string;
};

export type Medication = {
  id: string;
  name: string;
  generic_name?: string;
  description?: string;
  dosage_form?: string;
  strength?: string;
  manufacturer?: string;
  requires_prescription: boolean;
  category?: string;
  created_at: string;
  updated_at: string;
};

export type PharmacyMedication = {
  id: string;
  pharmacy_id: string;
  medication_id: string;
  price?: number;
  in_stock: boolean;
  stock_quantity?: number;
  last_updated: string;
};

export type Profile = {
  id: string;
  full_name: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  province: string | null;
  role: 'customer' | 'pharmacist' | 'admin';
  created_at: string;
  updated_at: string;
};

export type AccessLog = {
  id: string;
  user_id: string | null;
  action: string;
  ip_address: string | null;
  user_agent: string | null;
  timestamp: string;
};

export type Visitor = {
  id: string;
  session_id: string;
  ip_address: string | null;
  user_agent: string | null;
  first_visit_at: string;
  last_visit_at: string;
  visit_count: number;
  preferences: Record<string, any>;
  user_id: string | null;
};

export type Specialist = {
  id: string;
  user_id: string;
  full_name: string;
  specialization: string;
  license_number: string | null;
  bio: string | null;
  photo_url: string | null;
  availability: {
    [key: string]: { start: string; end: string };
  };
  is_online: boolean;
  created_at: string;
  updated_at: string;
};

export type ChatRoom = {
  id: string;
  user_id: string | null;
  specialist_id: string | null;
  status: 'pending' | 'active' | 'ended';
  chat_type: 'text' | 'video';
  started_at: string;
  ended_at: string | null;
  topic: string | null;
  metadata: Record<string, any>;
};

export type ChatMessage = {
  id: string;
  room_id: string;
  sender_id: string | null;
  message_type: 'text' | 'file' | 'call_started' | 'call_ended';
  content: string | null;
  metadata: Record<string, any>;
  sent_at: string;
  read_at: string | null;
  is_system_message: boolean;
};

export type PharmacyWithMedications = Pharmacy & {
  medications: (Medication & { 
    pharmacy_medication: PharmacyMedication 
  })[];
};

export type MedicationWithPharmacies = Medication & {
  pharmacies: (Pharmacy & { 
    pharmacy_medication: PharmacyMedication 
  })[];
};