import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import AuthForm from './components/Auth/AuthForm';
import Pharmacies from './components/Pharmacies/Pharmacies';
import Medications from './components/Medications/Medications';
import Consultations from './components/Consultations/Consultations';
import Profile from './components/Profile/Profile';
import ProtectedRoute from './components/Auth/ProtectedRoute';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <Features />
            </>
          } />
          <Route path="/auth" element={<AuthForm />} />
          <Route path="/pharmacies" element={<Pharmacies />} />
          <Route path="/medications" element={<Medications />} />
          <Route path="/consultations" element={<Consultations />} />
          <Route path="/profile" element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;