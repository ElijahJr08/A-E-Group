import React, { useState, useEffect } from 'react';
import { Calendar, Video, MessageSquare, Clock } from 'lucide-react';
import { getAvailableSpecialists } from '../../lib/api';
import type { Specialist } from '../../types/database.types';

const Consultations = () => {
  const [specialists, setSpecialists] = useState<Specialist[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSpecialization, setSelectedSpecialization] = useState<string>('');

  useEffect(() => {
    const loadSpecialists = async () => {
      const { data, error } = await getAvailableSpecialists();
      if (data) {
        setSpecialists(data);
      }
      setLoading(false);
    };

    loadSpecialists();
  }, []);

  const specializations = Array.from(new Set(specialists.map(spec => spec.specialization)));

  const filteredSpecialists = selectedSpecialization
    ? specialists.filter(spec => spec.specialization === selectedSpecialization)
    : specialists;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Consultas Online</h1>

      <div className="mb-6">
        <select
          className="w-full max-w-md px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
          value={selectedSpecialization}
          onChange={(e) => setSelectedSpecialization(e.target.value)}
        >
          <option value="">Todas especialidades</option>
          {specializations.map(spec => (
            <option key={spec} value={spec}>{spec}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSpecialists.map((specialist) => (
          <div key={specialist.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-center space-x-4 mb-4">
                {specialist.photo_url ? (
                  <img
                    src={specialist.photo_url}
                    alt={specialist.full_name}
                    className="h-16 w-16 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-16 w-16 rounded-full bg-emerald-100 flex items-center justify-center">
                    <span className="text-2xl text-emerald-600">
                      {specialist.full_name.charAt(0)}
                    </span>
                  </div>
                )}
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{specialist.full_name}</h2>
                  <p className="text-emerald-600">{specialist.specialization}</p>
                </div>
              </div>

              {specialist.bio && (
                <p className="text-gray-600 mb-4">{specialist.bio}</p>
              )}

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>Disponível agora</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button className="flex items-center justify-center bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700 transition-colors">
                  <Video className="h-5 w-5 mr-2" />
                  <span>Vídeo</span>
                </button>
                <button className="flex items-center justify-center bg-emerald-100 text-emerald-700 py-2 px-4 rounded-md hover:bg-emerald-200 transition-colors">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  <span>Chat</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Consultations;