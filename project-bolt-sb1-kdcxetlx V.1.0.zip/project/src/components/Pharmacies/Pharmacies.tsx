import React, { useState, useEffect } from 'react';
import { MapPin, Phone, Clock, Mail } from 'lucide-react';
import { getPharmacies } from '../../lib/api';
import type { Pharmacy } from '../../types/database.types';

const Pharmacies = () => {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadPharmacies = async () => {
      const { data, error } = await getPharmacies();
      if (data) {
        setPharmacies(data);
      }
      setLoading(false);
    };

    loadPharmacies();
  }, []);

  const filteredPharmacies = pharmacies.filter(pharmacy =>
    pharmacy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pharmacy.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pharmacy.province.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Farmácias</h1>
      
      <div className="mb-6">
        <input
          type="text"
          placeholder="Pesquisar farmácias..."
          className="w-full max-w-md px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPharmacies.map((pharmacy) => (
          <div key={pharmacy.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{pharmacy.name}</h2>
              
              <div className="space-y-3">
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-5 w-5 mr-2" />
                  <span>{pharmacy.address}, {pharmacy.city}, {pharmacy.province}</span>
                </div>
                
                {pharmacy.phone && (
                  <div className="flex items-center text-gray-600">
                    <Phone className="h-5 w-5 mr-2" />
                    <span>{pharmacy.phone}</span>
                  </div>
                )}
                
                {pharmacy.email && (
                  <div className="flex items-center text-gray-600">
                    <Mail className="h-5 w-5 mr-2" />
                    <span>{pharmacy.email}</span>
                  </div>
                )}
                
                <div className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>{pharmacy.is_24h ? 'Aberto 24h' : 'Horário comercial'}</span>
                </div>
              </div>

              <button className="mt-4 w-full bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700 transition-colors">
                Ver Medicamentos
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pharmacies;