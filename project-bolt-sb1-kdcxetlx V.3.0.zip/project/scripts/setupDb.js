import { createClient } from '@libsql/client';

const client = createClient({
  url: 'file:local.db',
});

async function setupDatabase() {
  try {
    // Create tables
    await client.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        full_name TEXT,
        phone TEXT,
        address TEXT,
        city TEXT,
        province TEXT,
        role TEXT DEFAULT 'customer',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.execute(`
      CREATE TABLE IF NOT EXISTS pharmacies (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        province TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        website TEXT,
        opening_hours TEXT,
        is_24h INTEGER DEFAULT 0,
        owner_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (owner_id) REFERENCES users(id)
      )
    `);

    await client.execute(`
      CREATE TABLE IF NOT EXISTS medications (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        generic_name TEXT,
        description TEXT,
        dosage_form TEXT,
        strength TEXT,
        manufacturer TEXT,
        requires_prescription INTEGER DEFAULT 0,
        category TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.execute(`
      CREATE TABLE IF NOT EXISTS pharmacy_medications (
        id TEXT PRIMARY KEY,
        pharmacy_id TEXT,
        medication_id TEXT,
        price REAL,
        in_stock INTEGER DEFAULT 1,
        stock_quantity INTEGER,
        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id),
        FOREIGN KEY (medication_id) REFERENCES medications(id),
        UNIQUE(pharmacy_id, medication_id)
      )
    `);

    // Insert sample data
    await client.execute(`
      INSERT INTO medications (id, name, generic_name, description, dosage_form, strength, manufacturer, requires_prescription, category)
      VALUES 
        ('med1', 'Paracetamol', 'Acetaminophen', 'Pain reliever and fever reducer', 'Tablet', '500mg', 'Generic', 0, 'Pain Relief'),
        ('med2', 'Ibuprofeno', 'Ibuprofen', 'Anti-inflammatory drug', 'Tablet', '400mg', 'Generic', 0, 'Pain Relief'),
        ('med3', 'Amoxicilina', 'Amoxicillin', 'Antibiotic', 'Capsule', '500mg', 'Generic', 1, 'Antibiotic')
      ON CONFLICT(id) DO NOTHING
    `);

    await client.execute(`
      INSERT INTO pharmacies (id, name, address, city, province, phone, email, is_24h)
      VALUES 
        ('pharm1', 'Farmácia Central', 'Av. 24 de Julho, 1234', 'Maputo', 'Maputo', '+258 21 123456', 'central@example.com', 1),
        ('pharm2', 'Farmácia Moderna', 'Av. Eduardo Mondlane, 567', 'Maputo', 'Maputo', '+258 21 234567', 'moderna@example.com', 0)
      ON CONFLICT(id) DO NOTHING
    `);

    await client.execute(`
      INSERT INTO pharmacy_medications (id, pharmacy_id, medication_id, price, stock_quantity)
      VALUES 
        ('pm1', 'pharm1', 'med1', 50.00, 100),
        ('pm2', 'pharm1', 'med2', 75.00, 50),
        ('pm3', 'pharm2', 'med1', 55.00, 75)
      ON CONFLICT(id) DO NOTHING
    `);

    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Error setting up database:', error);
  } finally {
    await client.close();
  }
}

setupDatabase();