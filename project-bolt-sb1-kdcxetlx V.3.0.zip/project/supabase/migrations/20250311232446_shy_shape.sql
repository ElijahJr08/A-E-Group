/*
  # Ensure Database Relationships

  1. Changes
    - Add missing foreign key relationships
    - Add indexes for better query performance
    - Update RLS policies for edit operations

  2. Security
    - Add policies for edit operations
    - Ensure proper access control
*/

-- Ensure pharmacy_medications relationships
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'pharmacy_medications_pharmacy_id_fkey'
  ) THEN
    ALTER TABLE pharmacy_medications
    ADD CONSTRAINT pharmacy_medications_pharmacy_id_fkey
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'pharmacy_medications_medication_id_fkey'
  ) THEN
    ALTER TABLE pharmacy_medications
    ADD CONSTRAINT pharmacy_medications_medication_id_fkey
    FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Add edit policies for pharmacies
CREATE POLICY "Pharmacy owners can edit their pharmacies"
ON pharmacies
FOR UPDATE
TO authenticated
USING (auth.uid() = owner_id)
WITH CHECK (auth.uid() = owner_id);

-- Add edit policies for medications in pharmacies
CREATE POLICY "Pharmacy owners can edit their medications"
ON pharmacy_medications
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM pharmacies
    WHERE pharmacies.id = pharmacy_medications.pharmacy_id
    AND pharmacies.owner_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM pharmacies
    WHERE pharmacies.id = pharmacy_medications.pharmacy_id
    AND pharmacies.owner_id = auth.uid()
  )
);

-- Add edit policies for user profiles
CREATE POLICY "Users can edit their own profiles"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_pharmacy_medications_composite 
ON pharmacy_medications(pharmacy_id, medication_id);

CREATE INDEX IF NOT EXISTS idx_pharmacies_owner 
ON pharmacies(owner_id);

CREATE INDEX IF NOT EXISTS idx_profiles_search 
ON profiles(full_name, phone);