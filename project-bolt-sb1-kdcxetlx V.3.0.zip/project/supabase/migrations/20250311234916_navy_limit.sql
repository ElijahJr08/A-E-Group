/*
  # User Permissions and Statistics Schema

  1. New Tables
    - `permissions`
      - Stores user role permissions
      - Controls access to different sections
    
    - `page_views`
      - Tracks page visits and statistics
      - Records user interactions
    
    - `user_agreements`
      - Stores user consent records
      - Tracks terms acceptance

  2. Security
    - Enable RLS
    - Add policies for access control
    - Protect sensitive information
*/

-- Create permissions table with role as enum type
CREATE TABLE IF NOT EXISTS permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL CHECK (role IN ('customer', 'pharmacist', 'admin')),
  resource text NOT NULL,
  can_view boolean DEFAULT false,
  can_edit boolean DEFAULT false,
  can_delete boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(role, resource)
);

-- Create page_views table
CREATE TABLE IF NOT EXISTS page_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id),
  page_path text NOT NULL,
  view_count integer DEFAULT 1,
  last_viewed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create user_agreements table
CREATE TABLE IF NOT EXISTS user_agreements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) UNIQUE,
  agreed_to_terms boolean DEFAULT false,
  agreed_to_statistics boolean DEFAULT false,
  agreement_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create statistics_summary table
CREATE TABLE IF NOT EXISTS statistics_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  period text NOT NULL,
  data jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(type, period)
);

-- Enable RLS
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE page_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_agreements ENABLE ROW LEVEL SECURITY;
ALTER TABLE statistics_summary ENABLE ROW LEVEL SECURITY;

-- Permissions policies
CREATE POLICY "Anyone can view permissions"
  ON permissions FOR SELECT
  TO authenticated
  USING (true);

-- Page views policies
CREATE POLICY "Admins can view all page views"
  ON page_views FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Users can create their own page views"
  ON page_views FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- User agreements policies
CREATE POLICY "Users can view their own agreements"
  ON user_agreements FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own agreements"
  ON user_agreements FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Statistics summary policies
CREATE POLICY "Admins can view statistics"
  ON statistics_summary FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Insert default permissions
INSERT INTO permissions (role, resource, can_view, can_edit, can_delete) VALUES
  ('customer', 'home', true, false, false),
  ('customer', 'pharmacies', true, false, false),
  ('customer', 'medications', true, false, false),
  ('customer', 'consultations', true, false, false),
  ('pharmacist', 'home', true, false, false),
  ('pharmacist', 'pharmacies', true, true, false),
  ('pharmacist', 'medications', true, true, false),
  ('pharmacist', 'consultations', true, false, false),
  ('admin', 'home', true, true, true),
  ('admin', 'pharmacies', true, true, true),
  ('admin', 'medications', true, true, true),
  ('admin', 'consultations', true, true, true),
  ('admin', 'statistics', true, true, true)
ON CONFLICT (role, resource) DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_page_views_user ON page_views(user_id);
CREATE INDEX IF NOT EXISTS idx_page_views_path ON page_views(page_path);
CREATE INDEX IF NOT EXISTS idx_permissions_role ON permissions(role);
CREATE INDEX IF NOT EXISTS idx_statistics_type_period ON statistics_summary(type, period);

-- Update trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add triggers
CREATE TRIGGER update_permissions_updated_at
  BEFORE UPDATE ON permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_agreements_updated_at
  BEFORE UPDATE ON user_agreements
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_statistics_summary_updated_at
  BEFORE UPDATE ON statistics_summary
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();