/*
  # Chat and Visitors System Schema

  1. New Tables
    - `visitors`
      - Anonymous visitors tracking
      - Stores basic info and preferences
    
    - `specialists`
      - Healthcare specialists available for consultation
      - Includes credentials and availability
    
    - `chat_rooms`
      - Manages chat sessions between users and specialists
      - Supports both text and video chat
    
    - `chat_messages`
      - Stores chat history
      - Supports text, attachments, and call records

  2. Security
    - Enable RLS on all tables
    - Add policies for user access
    - Add policies for specialist access
    - Protect sensitive information
*/

-- Create visitors table
CREATE TABLE IF NOT EXISTS visitors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text UNIQUE NOT NULL,
  ip_address text,
  user_agent text,
  first_visit_at timestamptz DEFAULT now(),
  last_visit_at timestamptz DEFAULT now(),
  visit_count integer DEFAULT 1,
  preferences jsonb DEFAULT '{}'::jsonb,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Create specialists table
CREATE TABLE IF NOT EXISTS specialists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  specialization text NOT NULL,
  license_number text,
  bio text,
  photo_url text,
  availability jsonb DEFAULT '{
    "monday": {"start": "09:00", "end": "17:00"},
    "tuesday": {"start": "09:00", "end": "17:00"},
    "wednesday": {"start": "09:00", "end": "17:00"},
    "thursday": {"start": "09:00", "end": "17:00"},
    "friday": {"start": "09:00", "end": "17:00"}
  }'::jsonb,
  is_online boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT specialists_user_unique UNIQUE (user_id)
);

-- Create chat_rooms table
CREATE TABLE IF NOT EXISTS chat_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  specialist_id uuid REFERENCES specialists(id) ON DELETE SET NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'ended')),
  chat_type text DEFAULT 'text' CHECK (chat_type IN ('text', 'video')),
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  topic text,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES chat_rooms(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'file', 'call_started', 'call_ended')),
  content text,
  metadata jsonb DEFAULT '{}'::jsonb,
  sent_at timestamptz DEFAULT now(),
  read_at timestamptz,
  is_system_message boolean DEFAULT false
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_visitors_session ON visitors(session_id);
CREATE INDEX IF NOT EXISTS idx_visitors_user ON visitors(user_id);
CREATE INDEX IF NOT EXISTS idx_specialists_online ON specialists(is_online);
CREATE INDEX IF NOT EXISTS idx_chat_rooms_user ON chat_rooms(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_rooms_specialist ON chat_rooms(specialist_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_room ON chat_messages(room_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_sender ON chat_messages(sender_id);

-- Enable Row Level Security
ALTER TABLE visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE specialists ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Policies for visitors
CREATE POLICY "Anyone can create visitor records"
  ON visitors
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can view their own visitor records"
  ON visitors
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR session_id IS NOT NULL);

-- Policies for specialists
CREATE POLICY "Anyone can view specialists"
  ON specialists
  FOR SELECT
  USING (true);

CREATE POLICY "Specialists can update their own profile"
  ON specialists
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Policies for chat_rooms
CREATE POLICY "Users can view their chat rooms"
  ON chat_rooms
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR specialist_id IN (
    SELECT id FROM specialists WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can create chat rooms"
  ON chat_rooms
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their chat rooms"
  ON chat_rooms
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() OR specialist_id IN (
    SELECT id FROM specialists WHERE user_id = auth.uid()
  ));

-- Policies for chat_messages
CREATE POLICY "Users can view messages in their rooms"
  ON chat_messages
  FOR SELECT
  TO authenticated
  USING (
    room_id IN (
      SELECT id FROM chat_rooms
      WHERE user_id = auth.uid()
      OR specialist_id IN (SELECT id FROM specialists WHERE user_id = auth.uid())
    )
  );

CREATE POLICY "Users can send messages to their rooms"
  ON chat_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    room_id IN (
      SELECT id FROM chat_rooms
      WHERE user_id = auth.uid()
      OR specialist_id IN (SELECT id FROM specialists WHERE user_id = auth.uid())
    )
  );

-- Create function to update visitor last visit
CREATE OR REPLACE FUNCTION update_visitor_last_visit()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_visit_at = now();
  NEW.visit_count = OLD.visit_count + 1;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for visitor updates
CREATE TRIGGER update_visitor_visit
  BEFORE UPDATE ON visitors
  FOR EACH ROW
  EXECUTE FUNCTION update_visitor_last_visit();

-- Create function to handle specialist status updates
CREATE OR REPLACE FUNCTION handle_specialist_status()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for specialist updates
CREATE TRIGGER update_specialist_status
  BEFORE UPDATE ON specialists
  FOR EACH ROW
  EXECUTE FUNCTION handle_specialist_status();