/*
  # Seed Data for Pharmacy and Medication Database

  This migration adds sample data for:
  1. Medications - Common medications used in Mozambique
  2. Pharmacies - Sample pharmacies in major cities
  3. Pharmacy_medications - Linking medications to pharmacies with prices
*/

-- Seed medications
INSERT INTO medications (name, generic_name, description, dosage_form, strength, manufacturer, requires_prescription, category)
VALUES
  ('Paracetamol', 'Acetaminophen', 'Pain reliever and fever reducer', 'Tablet', '500mg', 'Generic', false, 'Pain Relief'),
  ('Ibuprofeno', 'Ibuprofen', 'Nonsteroidal anti-inflammatory drug (NSAID)', 'Tablet', '400mg', 'Generic', false, 'Pain Relief'),
  ('Amoxicilina', 'Amoxicillin', 'Antibiotic used to treat bacterial infections', 'Capsule', '500mg', 'Generic', true, 'Antibiotic'),
  ('Metformina', 'Metformin', 'Oral diabetes medicine that helps control blood sugar levels', 'Tablet', '850mg', 'Generic', true, 'Diabetes'),
  ('Losartana', 'Losartan', 'Angiotensin II receptor blocker (ARB) that treats high blood pressure', 'Tablet', '50mg', 'Generic', true, 'Hypertension'),
  ('Enalapril', 'Enalapril', 'ACE inhibitor that treats high blood pressure', 'Tablet', '10mg', 'Generic', true, 'Hypertension'),
  ('Omeprazol', 'Omeprazole', 'Proton pump inhibitor that decreases stomach acid production', 'Capsule', '20mg', 'Generic', false, 'Gastrointestinal'),
  ('Loratadina', 'Loratadine', 'Antihistamine that reduces the effects of natural chemical histamine', 'Tablet', '10mg', 'Generic', false, 'Allergy'),
  ('Albendazol', 'Albendazole', 'Anthelmintic used to treat parasitic worm infections', 'Tablet', '400mg', 'Generic', false, 'Antiparasitic'),
  ('Artemeter + Lumefantrina', 'Artemether + Lumefantrine', 'Antimalarial medication', 'Tablet', '20mg/120mg', 'Generic', false, 'Antimalarial'),
  ('Hidroclorotiazida', 'Hydrochlorothiazide', 'Diuretic that treats fluid retention and high blood pressure', 'Tablet', '25mg', 'Generic', true, 'Hypertension'),
  ('Atenolol', 'Atenolol', 'Beta-blocker that treats high blood pressure', 'Tablet', '50mg', 'Generic', true, 'Hypertension'),
  ('Diazepam', 'Diazepam', 'Benzodiazepine that treats anxiety, muscle spasms, and seizures', 'Tablet', '5mg', 'Generic', true, 'Anxiety'),
  ('Fluconazol', 'Fluconazole', 'Antifungal medication', 'Capsule', '150mg', 'Generic', true, 'Antifungal'),
  ('Vitamina C', 'Ascorbic Acid', 'Vitamin C supplement', 'Tablet', '500mg', 'Generic', false, 'Vitamin');

-- Seed pharmacies
INSERT INTO pharmacies (name, address, city, province, phone, email, website, is_24h)
VALUES
  ('Farmácia Central', 'Av. 24 de Julho, 1234', 'Maputo', 'Maputo', '+258 21 123456', 'central@example.com', 'www.farmaciacentral.co.mz', true),
  ('Farmácia Moderna', 'Av. Eduardo Mondlane, 567', 'Maputo', 'Maputo', '+258 21 234567', 'moderna@example.com', 'www.farmaciamoderna.co.mz', false),
  ('Farmácia Popular', 'Rua dos Lusíadas, 890', 'Maputo', 'Maputo', '+258 21 345678', 'popular@example.com', 'www.farmaciapopular.co.mz', false),
  ('Farmácia da Beira', 'Av. Principal, 123', 'Beira', 'Sofala', '+258 23 123456', 'beira@example.com', 'www.farmaciabeira.co.mz', true),
  ('Farmácia Nampula', 'Rua Central, 456', 'Nampula', 'Nampula', '+258 26 123456', 'nampula@example.com', 'www.farmacianampula.co.mz', false),
  ('Farmácia Quelimane', 'Av. 7 de Setembro, 789', 'Quelimane', 'Zambézia', '+258 24 123456', 'quelimane@example.com', 'www.farmaciaquelimane.co.mz', false),
  ('Farmácia Tete', 'Rua Principal, 321', 'Tete', 'Tete', '+258 25 123456', 'tete@example.com', 'www.farmaciatete.co.mz', false),
  ('Farmácia Xai-Xai', 'Av. Samora Machel, 654', 'Xai-Xai', 'Gaza', '+258 28 123456', 'xaixai@example.com', 'www.farmaciaxaixai.co.mz', false),
  ('Farmácia Inhambane', 'Rua da Praia, 987', 'Inhambane', 'Inhambane', '+258 29 123456', 'inhambane@example.com', 'www.farmaciainhambane.co.mz', false),
  ('Farmácia Pemba', 'Av. Marginal, 159', 'Pemba', 'Cabo Delgado', '+258 27 123456', 'pemba@example.com', 'www.farmaciapemba.co.mz', false);

-- Seed pharmacy_medications (linking medications to pharmacies with prices)
-- Farmácia Central (Maputo)
INSERT INTO pharmacy_medications (pharmacy_id, medication_id, price, in_stock, stock_quantity)
SELECT 
  (SELECT id FROM pharmacies WHERE name = 'Farmácia Central'),
  id,
  CASE 
    WHEN name = 'Paracetamol' THEN 50
    WHEN name = 'Ibuprofeno' THEN 75
    WHEN name = 'Amoxicilina' THEN 120
    WHEN name = 'Metformina' THEN 180
    WHEN name = 'Losartana' THEN 200
    WHEN name = 'Omeprazol' THEN 150
    WHEN name = 'Loratadina' THEN 90
    WHEN name = 'Albendazol' THEN 100
    WHEN name = 'Artemeter + Lumefantrina' THEN 250
    WHEN name = 'Vitamina C' THEN 80
    ELSE 100
  END,
  true,
  FLOOR(RANDOM() * 100) + 10
FROM medications
WHERE name IN ('Paracetamol', 'Ibuprofeno', 'Amoxicilina', 'Metformina', 'Losartana', 'Omeprazol', 'Loratadina', 'Albendazol', 'Artemeter + Lumefantrina', 'Vitamina C');

-- Farmácia Moderna (Maputo)
INSERT INTO pharmacy_medications (pharmacy_id, medication_id, price, in_stock, stock_quantity)
SELECT 
  (SELECT id FROM pharmacies WHERE name = 'Farmácia Moderna'),
  id,
  CASE 
    WHEN name = 'Paracetamol' THEN 55
    WHEN name = 'Ibuprofeno' THEN 80
    WHEN name = 'Enalapril' THEN 190
    WHEN name = 'Hidroclorotiazida' THEN 130
    WHEN name = 'Atenolol' THEN 170
    WHEN name = 'Diazepam' THEN 160
    WHEN name = 'Fluconazol' THEN 220
    WHEN name = 'Vitamina C' THEN 85
    ELSE 100
  END,
  true,
  FLOOR(RANDOM() * 100) + 10
FROM medications
WHERE name IN ('Paracetamol', 'Ibuprofeno', 'Enalapril', 'Hidroclorotiazida', 'Atenolol', 'Diazepam', 'Fluconazol', 'Vitamina C');

-- Farmácia da Beira (Beira)
INSERT INTO pharmacy_medications (pharmacy_id, medication_id, price, in_stock, stock_quantity)
SELECT 
  (SELECT id FROM pharmacies WHERE name = 'Farmácia da Beira'),
  id,
  CASE 
    WHEN name = 'Paracetamol' THEN 45
    WHEN name = 'Ibuprofeno' THEN 70
    WHEN name = 'Amoxicilina' THEN 115
    WHEN name = 'Artemeter + Lumefantrina' THEN 240
    WHEN name = 'Albendazol' THEN 95
    WHEN name = 'Vitamina C' THEN 75
    ELSE 100
  END,
  true,
  FLOOR(RANDOM() * 100) + 10
FROM medications
WHERE name IN ('Paracetamol', 'Ibuprofeno', 'Amoxicilina', 'Artemeter + Lumefantrina', 'Albendazol', 'Vitamina C');

-- Add more pharmacy_medications for other pharmacies as needed