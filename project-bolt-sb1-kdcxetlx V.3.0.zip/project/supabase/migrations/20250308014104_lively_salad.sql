/*
  # Create Doctors Table

  1. New Table
    - `doctors`
      - Personal information (name, surname, birth date)
      - Professional details (specialization, academic level)
      - Contact information (email, WhatsApp, phone)
      - Links to auth.users and specialists tables
  
  2. Security
    - Enable RLS
    - Add policies for doctor access
    - Add policies for admin access
*/

-- Create doctors table
CREATE TABLE IF NOT EXISTS doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  specialist_id uuid REFERENCES specialists(id) ON DELETE CASCADE,
  first_name text NOT NULL,
  last_name text NOT NULL,
  birth_date date NOT NULL,
  specialization text NOT NULL,
  academic_level text NOT NULL,
  email text NOT NULL UNIQUE,
  whatsapp text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT doctors_user_unique UNIQUE (user_id),
  CONSTRAINT doctors_specialist_unique UNIQUE (specialist_id)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_doctors_specialization ON doctors(specialization);
CREATE INDEX IF NOT EXISTS idx_doctors_academic_level ON doctors(academic_level);

-- Enable Row Level Security
ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

-- Policies for doctors
CREATE POLICY "Anyone can view doctors"
  ON doctors
  FOR SELECT
  USING (true);

CREATE POLICY "Doctors can update their own profile"
  ON doctors
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage all doctors"
  ON doctors
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Create trigger to update updated_at
CREATE TRIGGER update_doctors_updated_at
  BEFORE UPDATE ON doctors
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();