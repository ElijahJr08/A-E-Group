/*
  # Fix doctors table policies and add remaining tables

  1. Changes
    - Drop existing policy and recreate it correctly
    - Add missing tables and relationships
    - Add proper RLS policies

  2. New Tables
    - `prescriptions`
      - Stores medical prescriptions
      - Links patients, doctors, and medications
    - `inventory_logs`
      - Tracks pharmacy inventory changes
      - Maintains audit trail of stock updates
    - `notifications`
      - System notifications for users
      - Alerts for low stock, prescription renewals, etc

  3. Security
    - Update doctors table policies
    - Enable RLS on new tables
    - Add appropriate access policies
*/

-- First fix the doctors policy issue
DO $$ 
BEGIN
  -- Drop the conflicting policy if it exists
  DROP POLICY IF EXISTS "Anyone can view doctors" ON doctors;
  
  -- Recreate the policy correctly
  CREATE POLICY "Anyone can view doctors" 
    ON doctors
    FOR SELECT 
    TO public
    USING (true);
END $$;

-- Create prescriptions table
CREATE TABLE IF NOT EXISTS prescriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES profiles(id),
  doctor_id uuid NOT NULL REFERENCES doctors(id),
  medication_id uuid NOT NULL REFERENCES medications(id),
  dosage text NOT NULL,
  frequency text NOT NULL,
  duration text NOT NULL,
  notes text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  issued_at timestamptz DEFAULT now(),
  valid_until timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on prescriptions
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;

-- Prescriptions policies
CREATE POLICY "Doctors can create prescriptions"
  ON prescriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM doctors 
      WHERE doctors.id = prescriptions.doctor_id 
      AND doctors.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view their own prescriptions"
  ON prescriptions
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = patient_id OR
    EXISTS (
      SELECT 1 FROM doctors 
      WHERE doctors.id = prescriptions.doctor_id 
      AND doctors.user_id = auth.uid()
    )
  );

-- Create inventory_logs table
CREATE TABLE IF NOT EXISTS inventory_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pharmacy_id uuid NOT NULL REFERENCES pharmacies(id),
  medication_id uuid NOT NULL REFERENCES medications(id),
  action text NOT NULL CHECK (action IN ('add', 'remove', 'adjust')),
  quantity integer NOT NULL,
  previous_quantity integer NOT NULL,
  new_quantity integer NOT NULL,
  reason text,
  performed_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on inventory_logs
ALTER TABLE inventory_logs ENABLE ROW LEVEL SECURITY;

-- Inventory logs policies
CREATE POLICY "Pharmacy owners can view their inventory logs"
  ON inventory_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM pharmacies
      WHERE pharmacies.id = inventory_logs.pharmacy_id
      AND pharmacies.owner_id = auth.uid()
    )
  );

CREATE POLICY "Pharmacy owners can create inventory logs"
  ON inventory_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM pharmacies
      WHERE pharmacies.id = inventory_logs.pharmacy_id
      AND pharmacies.owner_id = auth.uid()
    )
  );

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL CHECK (type IN ('info', 'warning', 'error', 'success')),
  related_entity_type text,
  related_entity_id uuid,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Notifications policies
CREATE POLICY "Users can view their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_doctor ON prescriptions(doctor_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON prescriptions(status);
CREATE INDEX IF NOT EXISTS idx_inventory_logs_pharmacy ON inventory_logs(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_inventory_logs_medication ON inventory_logs(medication_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);

-- Add trigger for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at triggers for prescriptions
CREATE TRIGGER update_prescriptions_updated_at
  BEFORE UPDATE ON prescriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();