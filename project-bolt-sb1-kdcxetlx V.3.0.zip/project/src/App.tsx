import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from './lib/supabase';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import AuthForm from './components/Auth/AuthForm';
import Pharmacies from './components/Pharmacies/Pharmacies';
import Medications from './components/Medications/Medications';
import Consultations from './components/Consultations/Consultations';
import Profile from './components/Profile/Profile';
import Statistics from './components/Admin/Statistics';
import AgreementModal from './components/UserAgreement/AgreementModal';
import ProtectedRoute from './components/Auth/ProtectedRoute';

function App() {
  const [user, setUser] = useState<any>(null);
  const [showAgreement, setShowAgreement] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        setUser(currentUser);

        if (currentUser) {
          // Check if user has agreed to terms
          const { data: agreement } = await supabase
            .from('user_agreements')
            .select('*')
            .eq('user_id', currentUser.id)
            .single();

          if (!agreement?.agreed_to_terms) {
            setShowAgreement(true);
          }
        }
      } catch (error) {
        console.error('Error checking user:', error);
      } finally {
        setLoading(false);
      }
    };

    checkUser();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user || null);
      
      if (session?.user) {
        const { data: agreement } = await supabase
          .from('user_agreements')
          .select('*')
          .eq('user_id', session.user.id)
          .single();

        if (!agreement?.agreed_to_terms) {
          setShowAgreement(true);
        }
      }
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  const handleAgreementAccept = () => {
    setShowAgreement(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        {showAgreement && user && (
          <AgreementModal
            onClose={() => setShowAgreement(false)}
            onAccept={handleAgreementAccept}
          />
        )}

        <Routes>
          <Route path="/" element={
            user ? (
              <Navigate to="/pharmacies" />
            ) : (
              <>
                <Hero />
                <Features />
              </>
            )
          } />
          
          <Route path="/auth" element={<AuthForm />} />
          
          <Route path="/pharmacies" element={
            <ProtectedRoute>
              <Pharmacies />
            </ProtectedRoute>
          } />
          
          <Route path="/medications" element={
            <ProtectedRoute>
              <Medications />
            </ProtectedRoute>
          } />
          
          <Route path="/consultations" element={
            <ProtectedRoute>
              <Consultations />
            </ProtectedRoute>
          } />
          
          <Route path="/profile" element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } />
          
          <Route path="/admin/statistics" element={
            <ProtectedRoute>
              <Statistics />
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;