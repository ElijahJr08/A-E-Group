import { supabase, isSupabaseConfigured } from './supabase';
import type { 
  Pharmacy, Medication, PharmacyMedication, Profile, AccessLog,
  Visitor, Specialist, ChatRoom, ChatMessage 
} from '../types/database.types';

// Profile API functions
export const getProfile = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('profiles')
    .select('*')
    .eq('id', supabase.auth.getUser().then(({ data }) => data.user?.id))
    .single();
};

export const updateProfile = async (profile: Partial<Profile>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: new Error('User not authenticated') };

  return await supabase
    .from('profiles')
    .update(profile)
    .eq('id', user.id)
    .select()
    .single();
};

// Visitor API functions
export const createVisitor = async (sessionId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  const { data: { user } } = await supabase.auth.getUser();
  
  return await supabase
    .from('visitors')
    .insert({
      session_id: sessionId,
      user_id: user?.id,
      ip_address: window.location.hostname,
      user_agent: navigator.userAgent
    })
    .select()
    .single();
};

export const updateVisitor = async (sessionId: string, preferences: Record<string, any>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  return await supabase
    .from('visitors')
    .update({ preferences })
    .eq('session_id', sessionId)
    .select()
    .single();
};

// Specialist API functions
export const getAvailableSpecialists = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }

  return await supabase
    .from('specialists')
    .select('*')
    .eq('is_online', true)
    .order('specialization');
};

export const updateSpecialistStatus = async (specialistId: string, isOnline: boolean) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  return await supabase
    .from('specialists')
    .update({ is_online: isOnline })
    .eq('id', specialistId)
    .select()
    .single();
};

// Chat API functions
export const createChatRoom = async (specialistId: string, chatType: 'text' | 'video', topic?: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: new Error('User not authenticated') };

  return await supabase
    .from('chat_rooms')
    .insert({
      user_id: user.id,
      specialist_id: specialistId,
      chat_type: chatType,
      topic,
      status: 'pending'
    })
    .select()
    .single();
};

export const sendMessage = async (roomId: string, content: string, type: 'text' | 'file' = 'text') => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: new Error('User not authenticated') };

  return await supabase
    .from('chat_messages')
    .insert({
      room_id: roomId,
      sender_id: user.id,
      message_type: type,
      content
    })
    .select()
    .single();
};

export const getRoomMessages = async (roomId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }

  return await supabase
    .from('chat_messages')
    .select('*')
    .eq('room_id', roomId)
    .order('sent_at');
};

export const markMessageAsRead = async (messageId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  return await supabase
    .from('chat_messages')
    .update({ read_at: new Date().toISOString() })
    .eq('id', messageId)
    .select()
    .single();
};

// Pharmacy API functions
export const getPharmacies = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .select('*')
    .order('name');
};

export const getPharmacyById = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .select(`
      *,
      pharmacy_medications(
        *,
        medications(*)
      )
    `)
    .eq('id', id)
    .single();
};

export const createPharmacy = async (pharmacy: Omit<Pharmacy, 'id' | 'created_at' | 'updated_at'>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .insert(pharmacy)
    .select()
    .single();
};

export const editPharmacy = async (id: string, data: Partial<Pharmacy>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .update(data)
    .eq('id', id)
    .select()
    .single();
};

export const deletePharmacy = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacies')
    .delete()
    .eq('id', id);
};

// Medication API functions
export const getMedications = async () => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: [], error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .select('*')
    .order('name');
};

export const getMedicationById = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .select(`
      *,
      pharmacy_medications(
        *,
        pharmacies(*)
      )
    `)
    .eq('id', id)
    .single();
};

export const createMedication = async (medication: Omit<Medication, 'id' | 'created_at' | 'updated_at'>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .insert(medication)
    .select()
    .single();
};

export const editMedication = async (id: string, data: Partial<Medication>) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .update(data)
    .eq('id', id)
    .select()
    .single();
};

export const deleteMedication = async (id: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('medications')
    .delete()
    .eq('id', id);
};

// Pharmacy Medication API functions
export const editPharmacyMedication = async (
  pharmacyId: string,
  medicationId: string,
  data: Partial<PharmacyMedication>
) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .update(data)
    .eq('pharmacy_id', pharmacyId)
    .eq('medication_id', medicationId)
    .select()
    .single();
};

// Upload profile photo
export const uploadProfilePhoto = async (file: File) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: new Error('User not authenticated') };

  const fileExt = file.name.split('.').pop();
  const fileName = `${user.id}/${Date.now()}.${fileExt}`;
  const filePath = `${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from('profile-photos')
    .upload(filePath, file);

  if (uploadError) {
    return { data: null, error: uploadError };
  }

  const { data: { publicUrl } } = supabase.storage
    .from('profile-photos')
    .getPublicUrl(filePath);

  return await supabase
    .from('profiles')
    .update({ profile_photo_url: publicUrl })
    .eq('id', user.id)
    .select()
    .single();
};

// Get pharmacy medications with details
export const getPharmacyMedicationsWithDetails = async (pharmacyId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .select(`
      *,
      medications (*),
      pharmacies (*)
    `)
    .eq('pharmacy_id', pharmacyId);
};

// Get medication availability across pharmacies
export const getMedicationAvailability = async (medicationId: string) => {
  if (!isSupabaseConfigured()) {
    console.warn('Supabase not configured');
    return { data: null, error: new Error('Supabase not configured') };
  }
  
  return await supabase
    .from('pharmacy_medications')
    .select(`
      *,
      pharmacies (*)
    `)
    .eq('medication_id', medicationId)
    .eq('in_stock', true)
    .order('price');
};