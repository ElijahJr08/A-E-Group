import { createClient } from '@libsql/client';

const client = createClient({
  url: 'file:local.db',
});

export async function getPharmacies() {
  const result = await client.execute('SELECT * FROM pharmacies ORDER BY name');
  return result.rows;
}

export async function getMedications() {
  const result = await client.execute('SELECT * FROM medications ORDER BY name');
  return result.rows;
}

export async function getPharmacyMedications(pharmacyId: string) {
  const result = await client.execute(`
    SELECT 
      pm.*,
      m.name as medication_name,
      m.generic_name,
      m.description,
      m.dosage_form,
      m.strength,
      m.manufacturer,
      m.requires_prescription,
      m.category
    FROM pharmacy_medications pm
    JOIN medications m ON m.id = pm.medication_id
    WHERE pm.pharmacy_id = ?
  `, [pharmacyId]);
  return result.rows;
}

export async function searchMedications(query: string) {
  const result = await client.execute(`
    SELECT * FROM medications 
    WHERE name LIKE ? OR generic_name LIKE ?
    ORDER BY name
  `, [`%${query}%`, `%${query}%`]);
  return result.rows;
}

export async function createPharmacy(data: any) {
  const result = await client.execute(`
    INSERT INTO pharmacies (
      id, name, address, city, province, phone, email, website, is_24h, owner_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    crypto.randomUUID(),
    data.name,
    data.address,
    data.city,
    data.province,
    data.phone,
    data.email,
    data.website,
    data.is_24h ? 1 : 0,
    data.owner_id
  ]);
  return result;
}

export async function updatePharmacy(id: string, data: any) {
  const result = await client.execute(`
    UPDATE pharmacies SET
      name = ?,
      address = ?,
      city = ?,
      province = ?,
      phone = ?,
      email = ?,
      website = ?,
      is_24h = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [
    data.name,
    data.address,
    data.city,
    data.province,
    data.phone,
    data.email,
    data.website,
    data.is_24h ? 1 : 0,
    id
  ]);
  return result;
}

export async function createMedication(data: any) {
  const result = await client.execute(`
    INSERT INTO medications (
      id, name, generic_name, description, dosage_form, strength, 
      manufacturer, requires_prescription, category
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    crypto.randomUUID(),
    data.name,
    data.generic_name,
    data.description,
    data.dosage_form,
    data.strength,
    data.manufacturer,
    data.requires_prescription ? 1 : 0,
    data.category
  ]);
  return result;
}

export async function updateMedication(id: string, data: any) {
  const result = await client.execute(`
    UPDATE medications SET
      name = ?,
      generic_name = ?,
      description = ?,
      dosage_form = ?,
      strength = ?,
      manufacturer = ?,
      requires_prescription = ?,
      category = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [
    data.name,
    data.generic_name,
    data.description,
    data.dosage_form,
    data.strength,
    data.manufacturer,
    data.requires_prescription ? 1 : 0,
    data.category,
    id
  ]);
  return result;
}

export async function updatePharmacyMedication(pharmacyId: string, medicationId: string, data: any) {
  const result = await client.execute(`
    UPDATE pharmacy_medications SET
      price = ?,
      in_stock = ?,
      stock_quantity = ?,
      last_updated = CURRENT_TIMESTAMP
    WHERE pharmacy_id = ? AND medication_id = ?
  `, [
    data.price,
    data.in_stock ? 1 : 0,
    data.stock_quantity,
    pharmacyId,
    medicationId
  ]);
  return result;
}