import React from 'react';
import { X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface AgreementModalProps {
  onClose: () => void;
  onAccept: () => void;
}

const AgreementModal: React.FC<AgreementModalProps> = ({ onClose, onAccept }) => {
  const handleAccept = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // First ensure the profile exists
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single();

      if (!profile) {
        await supabase
          .from('profiles')
          .insert({ id: user.id, role: 'customer' });
      }

      // Then create the agreement
      const { error } = await supabase
        .from('user_agreements')
        .insert({
          user_id: user.id,
          agreed_to_terms: true,
          agreed_to_statistics: true,
          agreement_date: new Date().toISOString()
        });

      if (error) throw error;
      onAccept();
    } catch (error) {
      console.error('Error saving agreement:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full mx-4 p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Termos de Uso e Privacidade</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="prose prose-emerald max-w-none mb-6">
          <h3>Termos de Uso</h3>
          <p>
            Ao utilizar o FarmaMoz, você concorda com os seguintes termos:
          </p>
          <ul>
            <li>Fornecer informações verdadeiras e precisas</li>
            <li>Não utilizar o serviço para fins ilegais</li>
            <li>Respeitar a privacidade de outros usuários</li>
            <li>Manter suas credenciais de acesso seguras</li>
          </ul>

          <h3>Política de Privacidade</h3>
          <p>
            Coletamos e processamos seus dados para:
          </p>
          <ul>
            <li>Melhorar nossos serviços</li>
            <li>Gerar estatísticas de uso anônimas</li>
            <li>Personalizar sua experiência</li>
            <li>Enviar notificações relevantes</li>
          </ul>

          <h3>Uso de Dados para Estatísticas</h3>
          <p>
            Seus dados serão utilizados de forma anônima para:
          </p>
          <ul>
            <li>Análise de padrões de uso</li>
            <li>Melhoria dos serviços</li>
            <li>Relatórios estatísticos</li>
            <li>Pesquisa e desenvolvimento</li>
          </ul>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Recusar
          </button>
          <button
            onClick={handleAccept}
            className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
          >
            Aceitar e Continuar
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgreementModal;