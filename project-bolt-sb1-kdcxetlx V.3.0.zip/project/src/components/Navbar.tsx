import React, { useState, useEffect } from 'react';
import { Heart, User, LogOut, BarChart } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

const Navbar = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isSupabaseConfigured()) {
      const getUser = async () => {
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const currentUser = sessionData.session?.user;
          setUser(currentUser || null);

          if (currentUser) {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('role')
              .eq('id', currentUser.id)
              .single();
            
            setUserRole(profileData?.role || '');
          }
        } catch (error) {
          console.error('Error fetching user:', error);
        } finally {
          setLoading(false);
        }
      };

      getUser();

      const { data: authListener } = supabase.auth.onAuthStateChange(
        async (event, session) => {
          setUser(session?.user || null);
          if (session?.user) {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('role')
              .eq('id', session.user.id)
              .single();
            
            setUserRole(profileData?.role || '');
          } else {
            setUserRole('');
          }
        }
      );

      return () => {
        authListener?.subscription.unsubscribe();
      };
    } else {
      setLoading(false);
    }
  }, []);

  const handleAuthClick = () => {
    navigate('/auth');
  };

  const handleLogout = async () => {
    if (isSupabaseConfigured()) {
      await supabase.auth.signOut();
      navigate('/');
    }
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Heart className="h-8 w-8 text-emerald-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">FarmaMoz</span>
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-emerald-600">Início</Link>
            <Link to="/pharmacies" className="text-gray-700 hover:text-emerald-600">Farmácias</Link>
            <Link to="/medications" className="text-gray-700 hover:text-emerald-600">Medicamentos</Link>
            <Link to="/consultations" className="text-gray-700 hover:text-emerald-600">Consultas</Link>
            
            {!loading && (
              user ? (
                <div className="flex items-center space-x-4">
                  {userRole === 'admin' && (
                    <Link to="/admin/statistics" className="flex items-center text-gray-700 hover:text-emerald-600">
                      <BarChart className="h-5 w-5 mr-1" />
                      <span>Estatísticas</span>
                    </Link>
                  )}
                  <Link to="/profile" className="flex items-center text-gray-700 hover:text-emerald-600">
                    <User className="h-5 w-5 mr-1" />
                    <span>{user.email?.split('@')[0]}</span>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="flex items-center text-gray-700 hover:text-emerald-600"
                  >
                    <LogOut className="h-5 w-5 mr-1" />
                    <span>Sair</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleAuthClick}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-md hover:bg-emerald-700"
                >
                  Entrar
                </button>
              )
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;