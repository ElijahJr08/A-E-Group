import React, { useState, useEffect } from 'react';
import { Pill, AlertCircle } from 'lucide-react';
import { getMedications } from '../../lib/api';
import type { Medication } from '../../types/database.types';

const Medications = () => {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  useEffect(() => {
    const loadMedications = async () => {
      const { data, error } = await getMedications();
      if (data) {
        setMedications(data);
      }
      setLoading(false);
    };

    loadMedications();
  }, []);

  const categories = Array.from(new Set(medications.map(med => med.category).filter(Boolean)));

  const filteredMedications = medications.filter(medication =>
    (medication.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (medication.generic_name?.toLowerCase() || '').includes(searchTerm.toLowerCase())) &&
    (!selectedCategory || medication.category === selectedCategory)
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Medicamentos</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <input
          type="text"
          placeholder="Pesquisar medicamentos..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        
        <select
          className="w-full md:w-48 px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="">Todas categorias</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMedications.map((medication) => (
          <div key={medication.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">{medication.name}</h2>
                <Pill className="h-6 w-6 text-emerald-600" />
              </div>

              {medication.generic_name && (
                <p className="text-gray-600 mb-2">
                  Nome genérico: {medication.generic_name}
                </p>
              )}

              {medication.description && (
                <p className="text-gray-600 mb-4">{medication.description}</p>
              )}

              <div className="space-y-2">
                {medication.dosage_form && (
                  <p className="text-sm text-gray-600">Forma: {medication.dosage_form}</p>
                )}
                {medication.strength && (
                  <p className="text-sm text-gray-600">Concentração: {medication.strength}</p>
                )}
                {medication.manufacturer && (
                  <p className="text-sm text-gray-600">Fabricante: {medication.manufacturer}</p>
                )}
              </div>

              {medication.requires_prescription && (
                <div className="mt-4 flex items-center text-amber-600">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  <span className="text-sm">Requer prescrição médica</span>
                </div>
              )}

              <button className="mt-4 w-full bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700 transition-colors">
                Encontrar em Farmácias
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Medications;