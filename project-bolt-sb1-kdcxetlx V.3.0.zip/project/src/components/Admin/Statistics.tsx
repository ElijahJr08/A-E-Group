import React, { useState, useEffect } from 'react';
import { BarChart, PieChart, Activity, Users, ShoppingBag, Building2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface StatisticsSummary {
  type: string;
  period: string;
  data: any;
}

const Statistics = () => {
  const [statistics, setStatistics] = useState<StatisticsSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('daily');

  useEffect(() => {
    loadStatistics();
  }, [selectedPeriod]);

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase
        .from('statistics_summary')
        .select('*')
        .eq('period', selectedPeriod)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setStatistics(data || []);
    } catch (error) {
      console.error('Error loading statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Estatísticas</h1>
        <select
          value={selectedPeriod}
          onChange={(e) => setSelectedPeriod(e.target.value)}
          className="rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
        >
          <option value="daily">Diário</option>
          <option value="weekly">Semanal</option>
          <option value="monthly">Mensal</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Usuários Ativos</h3>
            <Users className="h-6 w-6 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {statistics.find(s => s.type === 'active_users')?.data?.count || 0}
          </p>
          <p className="text-sm text-gray-500 mt-2">Últimas 24 horas</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Visualizações</h3>
            <Activity className="h-6 w-6 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {statistics.find(s => s.type === 'page_views')?.data?.total || 0}
          </p>
          <p className="text-sm text-gray-500 mt-2">Total de visualizações</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Medicamentos</h3>
            <ShoppingBag className="h-6 w-6 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {statistics.find(s => s.type === 'medications')?.data?.total || 0}
          </p>
          <p className="text-sm text-gray-500 mt-2">Total cadastrado</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Farmácias</h3>
            <Building2 className="h-6 w-6 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {statistics.find(s => s.type === 'pharmacies')?.data?.total || 0}
          </p>
          <p className="text-sm text-gray-500 mt-2">Total cadastrado</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Medicamentos Mais Procurados
          </h3>
          <div className="space-y-4">
            {(statistics.find(s => s.type === 'top_medications')?.data?.items || []).map((item: any, index: number) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-gray-600">{item.name}</span>
                <span className="text-emerald-600 font-medium">{item.count} buscas</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Farmácias Mais Visitadas
          </h3>
          <div className="space-y-4">
            {(statistics.find(s => s.type === 'top_pharmacies')?.data?.items || []).map((item: any, index: number) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-gray-600">{item.name}</span>
                <span className="text-emerald-600 font-medium">{item.visits} visitas</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Statistics;