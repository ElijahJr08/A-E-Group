import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export const usePageView = () => {
  const location = useLocation();

  useEffect(() => {
    const recordPageView = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Check if page view exists for this user and path
        const { data: existingView } = await supabase
          .from('page_views')
          .select('*')
          .eq('user_id', user.id)
          .eq('page_path', location.pathname)
          .single();

        if (existingView) {
          // Update existing page view
          await supabase
            .from('page_views')
            .update({
              view_count: existingView.view_count + 1,
              last_viewed_at: new Date().toISOString()
            })
            .eq('id', existingView.id);
        } else {
          // Create new page view
          await supabase
            .from('page_views')
            .insert({
              user_id: user.id,
              page_path: location.pathname
            });
        }
      } catch (error) {
        console.error('Error recording page view:', error);
      }
    };

    recordPageView();
  }, [location.pathname]);
};