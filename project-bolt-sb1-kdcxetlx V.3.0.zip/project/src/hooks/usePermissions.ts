import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Permission {
  resource: string;
  can_view: boolean;
  can_edit: boolean;
  can_delete: boolean;
}

export const usePermissions = () => {
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPermissions = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          setPermissions([]);
          return;
        }

        // Get user role first
        const { data: profileData } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();

        if (profileData?.role) {
          // Get permissions for user's role
          const { data: permissionsData } = await supabase
            .from('permissions')
            .select('*')
            .eq('role', profileData.role);

          setPermissions(permissionsData || []);
        }
      } catch (error) {
        console.error('Error loading permissions:', error);
      } finally {
        setLoading(false);
      }
    };

    loadPermissions();
  }, []);

  const hasPermission = (resource: string, action: 'view' | 'edit' | 'delete' = 'view') => {
    const permission = permissions.find(p => p.resource === resource);
    if (!permission) return false;

    switch (action) {
      case 'view':
        return permission.can_view;
      case 'edit':
        return permission.can_edit;
      case 'delete':
        return permission.can_delete;
      default:
        return false;
    }
  };

  return { permissions, loading, hasPermission };
};